# Portfolio Website

This is the personal portfolio of **Dr. Vijayalaxmi V. Sonkamble**, highlighting research, projects, publications, and skills.

## Deployment

### GitHub Pages
1. Push files to GitHub repository.
2. Go to **Settings > Pages**.
3. Select branch `main` and folder `/root`.
4. Your site will be live at `https://yourusername.github.io/portfolio`.

### Netlify
1. Login to [Netlify](https://www.netlify.com/).
2. Drag & drop this folder.
3. Your site will be live instantly.
